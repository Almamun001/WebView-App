package com.devmats.readershub;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WebsiteAdapter extends RecyclerView.Adapter<WebsiteAdapter.WebsiteViewHolder> {
    private Context context;
    private List<Website> websiteList;

    public WebsiteAdapter(Context context, List<Website> websiteList) {
        this.context = context;
        this.websiteList = websiteList;
    }

    @Override
    public WebsiteViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // Inflate the custom layout for the list item (without CardView)
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.item_webview, parent, false);
        return new WebsiteViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(WebsiteViewHolder holder, int position) {
        // Get the website item from the list
        Website website = websiteList.get(position);

        // Set the name and URL in the corresponding TextViews
        holder.nameTextView.setText(website.getName());
        holder.urlTextView.setText(website.getUrl());

        // Set click listener for the item to open the website in WebViewActivity
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, WebViewActivity.class);
            intent.putExtra("URL", website.getUrl());
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return websiteList.size();
    }

    public static class WebsiteViewHolder extends RecyclerView.ViewHolder {
        TextView nameTextView;
        TextView urlTextView;

        public WebsiteViewHolder(View view) {
            super(view);
            // Initialize the TextViews
            nameTextView = view.findViewById(R.id.item_name);  // Make sure this ID matches the one in your XML
            urlTextView = view.findViewById(R.id.item_url);    // Make sure this ID matches as well
        }
    }
}
