package com.devmats.readershub;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private WebsiteAdapter adapter;
    private List<Website> websiteList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        websiteList = new ArrayList<>();
        websiteList.add(new Website("Comick.io", "https://www.comick.io"));
        websiteList.add(new Website("AsuraScans", "https://www.asurascans.net"));
        websiteList.add(new Website("Webtoon", "https://www.webtoons.com"));
        websiteList.add(new Website("ManhwaClan", "https://www.manhwaclan.com"));
        websiteList.add(new Website("MangaDex", "https://mangadex.org"));
        websiteList.add(new Website("MangaFox", "https://www.mangafox.net"));
        websiteList.add(new Website("ToonGod", "https://www.toongod.org"));
        websiteList.add(new Website("BeeBom", "https://www.beebom.com"));
        websiteList.add(new Website("Mangakaklot", "https://www.mangakakalot.com"));
        websiteList.add(new Website("Manganelo", "https://www.manganelo.com"));

        adapter = new WebsiteAdapter(this, websiteList);
        recyclerView.setAdapter(adapter);
    }
}
